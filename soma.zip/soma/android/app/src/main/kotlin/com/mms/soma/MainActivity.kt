package com.mms.soma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
